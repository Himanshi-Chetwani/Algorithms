import java.util.Arrays;
import java.util.Random;

public class GraphInputGenerator {

    private static Random rand = new Random();
    // Adjacency matarix
    private  int[][] adj;
    private  int vertices, edges;
    private boolean isWeighted, isDirected;
	public int[][] getAdj(){
        return this.adj;
    }
    public GraphInputGenerator(int v, int e, boolean isWeighted,boolean isDirected)
    {
	adj = new int[v][v];
	this.vertices = v;
	this.isWeighted = isWeighted;
	this.isDirected = isDirected;
	// Maximum possible edges check
	this.edges = isDirected ? Math.min(e, v * (v - 1)) : Math.min(e, v* (v - 1) / 2);
	fillAdj();
    }

    private void fillAdj() {
	int count = 0;
	while (count < edges)
	    {
		int v1 = rand.nextInt(vertices);
		int v2 = v1;
		while (v2 == v1)
		    {
			v2 = rand.nextInt(vertices);
		    }
	    if (addEdge(v1, v2))
		count += 1;
	    }

		//System.out.println(Arrays.toString(adj));
    }

    /** 
     * Adds a edge between vertices v1 and v2 and makes entry into the adjacency * matrix accordingly. For non weighted graphs, the edge cost 
     is 1. For non * directed graphs, the adjacency matrix is updated for both the vertices. *  
    */
    private boolean addEdge(int v1, int v2)
    {
	if (adj[v1][v2] == 0)
	    {
		int e = 1;
		if (isWeighted)
		    {
			e += rand.nextInt(edges * edges / 2);
		    }
		adj[v1][v2] = e;
		if (!isDirected)
		    adj[v2][v1] = e;
		return true;
	    }
	return false;
    }

    /** * Prints the graph data. First line contains number of vertices and number * of edges. Following lines show edges in the graph. If the graph is * weighted, the cost is also shown. */
    public void genGraphInput()
    {
	System.out.println(vertices + " " + edges);
	for (int i = 0; i < adj.length; i++)
	    {
    		for (int j = isDirected ? 0 : 0; j < adj.length; j++)
		    {
			if (adj[i][j] != 0)
			    {
				System.out.println(i + " " + j+ ((isWeighted) ?
                        " " + adj[i][j] : ""));
			    }
		    }
	    }
    }

    public static void main(String[] args)
    {

	/*System.out.println("Non-weighted undirected graph:");
	GraphInputGenerator g = new GraphInputGenerator(v, e, false, false);
	g.genGraphInput();*/

	/*System.out.println("Non-weighted directed graph:");
	g = new GraphInputGenerator(v, e, false, true);
	g.genGraphInput();
	System.out.println("Weighted directed graph:");
	g = new GraphInputGenerator(v, e, true, true);
	g.genGraphInput();*/
    }
}
