import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;

public class Kruskals {
    public static int v;
    public static int e;
    private static int[][] weights;
    private void sortingEdges(SortedEdges[] sortE){

        int counter=0;
        for (int i = 0; i < weights.length; i++) {
            for (int j = i; j < weights[0].length; j++)
                if (weights[i][j] != 0) {
                    sortE[counter] = new SortedEdges(i, j, weights[i][j]);
                    counter++;
                }
        }
        Arrays.sort(sortE);
    }
    static LinkedList<Integer>[] convertToList(int[][] adjMat){
        LinkedList<Integer> adjList[]=new LinkedList[v];
        for(int i = 0; i < v ; i++){
            adjList[i] = new LinkedList<>();
        }
        for(int source=0;source<v;source++){
            for (int dest=0;dest<v;dest++){
                if(adjMat[source][dest]!=0) {
                    adjList[source].add(dest);
                    adjList[dest].add(source);
                }
            }

        }
        return adjList;
    }

    public static void main(String[] args) {
        long StartTime;
        long endTime;
        long set1w,set2w,set3w;
        long set1wo,set2wo,set3wo;
        NumberFormat formatter = new DecimalFormat("#0.00000");
        //  Number of vertices
         v = Integer.parseInt(args[0]);
        // Number of edges
         e = Integer.parseInt(args[1]);
        //Object of class Kruskals
        Kruskals kruskals = new Kruskals();
        // An array of edges which also give details about its source and
        // destination
        SortedEdges sortingEdges[] = new SortedEdges[e];
        //Creating a graph which is weighted but undirected
       // for(int i=0;i<15;i++) {
            System.out.println("Set 3:");
            GraphInputGenerator g = new GraphInputGenerator(v, e, true, false);
            g.genGraphInput();
            //Getting the adjacency matrix that represets the graph
            weights = g.getAdj();
            //Sorting all the edges in a non-decreasing order
            StartTime = System.currentTimeMillis();
            kruskals.sortingEdges(sortingEdges);
            //Finds the MCST using Union and Find Method
            VertexSubset vertexSubset = new VertexSubset();
            //boolean result=cyclicity.findingCyclicity(sortingEdges);
            vertexSubset.creatingSubsets(sortingEdges);
            endTime = System.currentTimeMillis();
            set3w = endTime - StartTime;
            //System.out.println("Set 3 with  U&F : " + formatter.format(
        // (set3w) / 1000d));
            StartTime = System.currentTimeMillis();
            new Cyclicity().findingCyclicity(sortingEdges);
            endTime = System.currentTimeMillis();
            set3wo = endTime - StartTime;
            //System.out.println("Set 3 without  U&F : " + formatter.format(
        // (set3wo) / 1000d));
            System.out.println("Set 1:");
            g.genGraphInput();
            StartTime = System.currentTimeMillis();
            kruskals.sortingEdges(sortingEdges);
            vertexSubset.creatingSubsets(sortingEdges);
            endTime = System.currentTimeMillis();
            set1w = endTime - StartTime;
            //System.out.println("Set 1 with  U&F : " + formatter.format(
        // (set1w) / 1000d));
            StartTime = System.currentTimeMillis();
            new Cyclicity().findingCyclicity(sortingEdges);
            endTime = System.currentTimeMillis();
            set1wo = endTime - StartTime;
            //System.out.println("Set 1 without  U&F : " + formatter.format(
        // (set1wo) / 1000d));
            System.out.println("Set 2:");
            g.genGraphInput();
            StartTime = System.currentTimeMillis();
            kruskals.sortingEdges(sortingEdges);
            vertexSubset.creatingSubsets(sortingEdges);
            endTime = System.currentTimeMillis();
            set2w = endTime - StartTime;
            //System.out.println("Set 2 with  U&F : " + formatter.format(
        // (set2w) / 1000d));
            StartTime = System.currentTimeMillis();
            new Cyclicity().findingCyclicity(sortingEdges);
            endTime = System.currentTimeMillis();
            set2wo = endTime - StartTime;
           // System.out.println("Set 3 with  U&F : " + formatter.format(
        // (set2wo) / 1000d));
       // }

    }
}
