import java.util.Random;

public class Set1AndSet2 {


    private static Random rand = new Random();

    public int[][] genSet1(int vertices, int edges) {
        int[][] adj = new int[vertices][edges];
        for (int source = 0; source < vertices; source++) {
            int loop = rand.nextInt((10 - 1) + 1) + 1;
            for (int index = 0; index <= loop; index++) {
                int dest = rand.nextInt((vertices));
                while (dest == source) {
                    dest = rand.nextInt((vertices) );
                }
                adj[source][dest] = rand.nextInt(edges * edges / 2);
            }
        }
        return adj;
    }

    public int[][] genSet2(int vertices, int edges) {
        int[][] adj = new int[vertices][edges];
        int upperlimit = (vertices * (vertices - 1)) / 2;
        for (int source = 0; source < vertices; source++) {
            int loop = rand.nextInt(upperlimit - (vertices / 2) + vertices / 2) + 1;
            for (int index = 0; index <= loop; index++) {
                int dest = rand.nextInt((vertices) );
                while (dest == source) {
                    dest = rand.nextInt((vertices)) ;
                }
                adj[source][dest] = rand.nextInt(edges * edges / 2);
            }
        }
        return adj;
    }

    public void print(int[][] adj) {
        for (int i = 0; i < adj.length; i++) {
            for (int j = 0; j < adj.length; j++) {
                if (adj[i][j] != 0) {
                    System.out.println(i + " " + j + " " + adj[i][j] + "");
                }
            }
        }
    }


}
