public class SortedEdges implements Comparable<SortedEdges> {
     int source;
     int destination;
     int weight;
    public SortedEdges(int source, int destination, int weight){
        this.source=source;
        this.destination=destination;
        this.weight=weight;
    }
    @Override
    public int compareTo(SortedEdges o) {
        return this.weight-o.weight;
    }
    public String toString (){
        return this.weight+"";
    }


}
