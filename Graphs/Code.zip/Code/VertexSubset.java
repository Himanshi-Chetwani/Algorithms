import java.util.Arrays;

class VertexSubset {
    private int parent;
    private int rank;

    private void Union(VertexSubset vertexTree[], int parent_vertex1,
                       int parent_vertex2) {
        int set1 = find(vertexTree, parent_vertex1);
        int set2 = find(vertexTree, parent_vertex2);
        if (vertexTree[set1].rank < vertexTree[set2].rank) {
            vertexTree[set1].parent = set2;
        } else if (vertexTree[set1].rank > vertexTree[set2].rank) {
            vertexTree[set2].parent = set1;
        }
        else {
            vertexTree[set2].parent = set1;
            vertexTree[set1].rank++;
        }
    }

    private int find(VertexSubset[] vertexTree, int pos) {
        if (vertexTree[pos].parent != pos)
            vertexTree[pos].parent = find(vertexTree, vertexTree[pos].parent);

        return vertexTree[pos].parent;
    }

    void creatingSubsets(SortedEdges[] sortingEdges) {
        SortedEdges result[] = new SortedEdges[Kruskals.v];
        int h = 0;
        for (int i = 0; i < Kruskals.v; i++) {
            result[i] = new SortedEdges(0, 0, 0);
        }
        VertexSubset vertexTree[] = new VertexSubset[Kruskals.v];
        for (int loopVariable = 0; loopVariable < Kruskals.v; loopVariable++) {
            vertexTree[loopVariable] = new VertexSubset();
        }
        for (int loopVariable = 0; loopVariable < Kruskals.v; loopVariable++) {
            vertexTree[loopVariable].parent = loopVariable;
            vertexTree[loopVariable].rank = 0;
        }
        int loopVariable = 0;

        while (h < Kruskals.v - 1) {
            int parent_vertex1 = find(vertexTree,
                    sortingEdges[loopVariable].source);
            int parent_vertex2 = find(vertexTree,
                    sortingEdges[loopVariable].destination);
            if (parent_vertex1 != parent_vertex2) {
                result[h++] = sortingEdges[loopVariable];
                Union(vertexTree, parent_vertex1, parent_vertex1);

            }
            loopVariable++;

        }
        for (int i = 0; i < h; ++i) {
            System.out.println("Source -> Destination -> Weight");
            System.out.println(result[i].source + "->" +
                    result[i].destination + "->" + result[i].weight);
        }
    }
}
