import java.util.*;

class Cyclicity {
     static   List<Integer> res = new ArrayList<>();

    private Boolean isCyclicHelper(int v, Boolean visited[], int parent, LinkedList<Integer>[] adj)
    {
        visited[v] = true;
        Integer i;

        for (Integer integer : adj[v]) {
            i = integer;
            if (!visited[i]) {
                if (isCyclicHelper(i, visited, v, adj))
                    return true;
            } else if (i != parent)
                return true;
        }
        return false;
    }

    private Boolean isCyclic(LinkedList<Integer>[] adj)
    {
        Boolean visited[] = new Boolean[Kruskals.v];
        for (int i = 0; i < visited.length; i++)
            visited[i] = false;

        for (int u = 0; u < visited.length; u++)
            if (!visited[u])
                if (isCyclicHelper(u, visited, -1,adj))
                    return true;

        return false;
    }





    void findingCyclicity(SortedEdges[] sortingEdges) {
        boolean res_b=false;
        int src;
        int dest;
        int wt;
        int adj_new[][] = new int[Kruskals.v][Kruskals.v];
        for (int i = 0; i < adj_new.length; i++) {
            for (int j = 0; j < adj_new.length; j++) {
                adj_new[i][j] = 0;
            }
        }
        SortedEdges res[]=new SortedEdges[Kruskals.v];
        int loop = 0;
        int k=0;
        for( loop=0;loop<Kruskals.v;loop  ++) {
            src = sortingEdges[loop].source;
            dest = sortingEdges[loop].destination;
            wt = sortingEdges[loop].weight;
            adj_new[src][dest] = wt;
            LinkedList<Integer> adjList[] = Kruskals.convertToList(adj_new);
            res_b=isCyclic(adjList);
            if(!res_b){
                res[k++]=sortingEdges[loop];
            }


        }
        System.out.println("W/O Union and Find");
        for (int i = 0; i < k; ++i) {
            System.out.println("Source -> Destination -> Weight");
            System.out.println(res[i].source + "->" +
               res[i].destination + "->" + res[i].weight);
        }

    }

}
